#if !defined(EFILTER_H)
#define EFILTER_H

#define ZONE_INIT 1

#endif // EFILTER_H
